#include <stdio.h> // printf/scanf
#include <stdlib.h> // malloc/free and NULL

struct stack {
	
	int *contents; //dynamic array of ints
	int top; //stores the top of the stack
	
 
}//*test = NULL;

void init(struct stack *s); // initialize stack members
void push(struct stack *s, int); // grow contents to store int
void pop(struct stack *s); // shrink contents and return top int
int stk_count();
void print_top();


int main() {
	
	struct stack s;
	int temp, temp2;
	
	temp = s.top;
	
		push(&s, temp);
		push(&s, temp);
		push(&s, temp);
		
		pop(&s);
	
	print_top();
	return 0;
}

void init(struct stack *s){
    *top = 0;
}

void push(struct stack *s, int size)
{
    int val,count;
	int MAX = 5;
    struct stack *temp;
    temp = (struct stack*)malloc(size);
 
    count = stk_count();
    if (count <= MAX - 1)
    {
        printf("\nEnter value to push into stack : ");
        scanf("%d",&val);
        temp->top = val;
        temp->contents = test;
        test = temp;
    }
    else
        printf("stack is full\n");
}

int stk_count()
{
    int count = 0;
    struct stack *temp;
    temp = test;
    while (temp != NULL)
    {
        temp = temp->contents;
        count++;
    }
    return count;
}

void pop(struct stack *s)
{
    struct stack *temp;
	int top2;
    if (test == NULL)
        printf("**Stack is empty**\n");
    else
    {
        temp = test;
        printf("Value popped out is %d \n",temp->top);
        test = test->contents;
        free(temp);
    }
} 

void print_top() {
	
	if (test == NULL) {
		printf("\nEmpty stack \n");
	}
	else {
		printf("\nTop of the stack is %d \n", test->top);
	}
}