#pragma once
#ifndef Header_h
#define Header_h

//Libraries
#include <iostream>
#include <string>
#include <cmath>
#include <stdlib.h>

using namespace std;


struct mult_div_values {
	int mult;
	float div;
};

mult_div_values** create_table(int r, int c);
bool is_value_diminsions(string input);
void set_mult_values(mult_div_values **table, int r, int c);
void set_div_values(mult_div_values **table, int r, int c);
void print_tables(mult_div_values **table, int r, int c);
void delete_table(mult_div_values ** table, int r, int c);

#endif
