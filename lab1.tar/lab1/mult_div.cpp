#include "mult_div.h"


//ALL FUNCTIONS

bool is_value_diminsions(string input)
{

	for (int x = 0; x < input.size(); x++) {
		if (input[x] < 48 || input[x] > 57) {
			cout << "Bad input, enter numbers" << endl;
			return false;
		}
	}
	return true;
}


mult_div_values** create_table(int r, int c) {

	mult_div_values **table = new mult_div_values*[r];


	for (int i = 0; i < r; i++)
		table[i] = new mult_div_values[c];

	return table;
}

void set_mult_values(mult_div_values **table, int r, int c)
{
	for (int i = 1; i <= r; i++) {
		for (int j = 1; j <= c; j++) {
			table[i - 1][j - 1].mult = (i * j);
		}
	}
}

void set_div_values(mult_div_values **table, int r, int c)
{
	for (int i = 1; i <= r; i++) {
		for (int j = 1; j <= c; j++) {
			table[i - 1][j - 1].div = ((float)i) / ((float)j);
		}
	}
}


void delete_table(mult_div_values **table, int r, int c)
{
	for (int i = 0; i < r; i++) {
		delete[] table[i];
	}
	delete[] table;
}


void print_tables(mult_div_values **table, int r, int c)
{
	// Print Multiplication Table
	cout << "Print Multiplication Table" << endl;
	cout << endl;
	
	for (int i = 0; i < r; i++) {
		for (int j = 0; j < c; j++) {
			cout << table[i][j].mult << " ";
		}
		cout << endl;
	}
	
	// Print Division Table
	cout << "Print Division Table" << endl;
	cout << endl;
	
	for (int m = 0; m < r; m++) {
		for (int n = 0; n < c; n++) {
			cout << table[m][n].div << " ";
		}
		cout << endl;
	}
	
}
