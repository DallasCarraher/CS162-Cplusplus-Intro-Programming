//
//
#include "mult_div.h"

int main (int argc, char *argv[])
{
	int rows = atoi(argv[1]); // convert to int
	int cols = atoi(argv[2]); // convert to int
	mult_div_values **table;
	table = create_table(rows, cols);
	set_mult_values(table, rows, cols);
	set_div_values(table, rows, cols);
	print_tables(table, rows, cols);
	delete_table(table, rows, cols);
	cout << endl;
	
	return 0;
}

