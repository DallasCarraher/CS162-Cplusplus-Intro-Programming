//
#include "ltr_header"

#define NUM_LETTERS 26

//check the last part of main where I am printing, you will get it.

struct Letters{
int count;
char ch;
};



int main(){

ifstream inFile;
char ch;
int i;

Letters stats[NUM_LETTERS];

inFile.open("file_fun.txt");

if (inFile.fail()){

cout << "bad input";
return 1;

}

//initialize the array of structures

for (i=0; i<NUM_LETTERS; i++)

{

stats[i].count=0;

stats[i].ch=('a' + i);

}

//do till file ends

while (!inFile.eof()){

inFile.get(ch);

//increment counter for appropriate character



if('a' <= ch && ch <= 'z')

stats[ch - 'a'].count++;

else if('A' <= ch && ch <= 'Z')

stats[ch - 'A'].count++;
}

inFile.close();

//print characters and count if it is more than 0

for(i=0;i<NUM_LETTERS;i++)

{

if(stats[i].count>0)

{

cout<<stats[i].ch<<" occured "<<stats[i].count<<" times"<<endl;

}

}



return 0;

}
