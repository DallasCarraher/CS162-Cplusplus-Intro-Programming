//
//  list.c
//  
//
//  Created by Dallas Carraher on 6/5/16.
//  implementation file for function prototypes
//

#include "list.h"

int length(struct list l){
    struct node *temp = l.head;
    int count = 0;
    while (temp != NULL)
    {
        count++;
        temp = temp -> next;
    }
    printf("Total number of nodes created: %i \n", count);
    return(count);
}


void push_front(struct list *myList, int input){
    struct node *temp = (struct node *) malloc(sizeof(struct node));
    temp -> val = input;
    temp -> next = NULL;
    temp -> prev = NULL;

    if (myList -> head == NULL)
    {
        myList -> head = temp;
    }
    else
    {
        myList -> head -> prev = temp;
        temp -> next = myList -> head;
        myList -> head = temp;
    }
}


void push_back(struct list *myList, int input){
    struct node *temp = (struct node *) malloc(sizeof(struct node));
    temp -> val = input;
    temp -> next = NULL;
    temp -> prev = NULL;
    
    if (myList -> tail == NULL)
    {
        myList -> head -> next = myList -> tail;
        myList -> tail = temp;
    }
    else
    {
        myList -> tail -> next = temp;
        temp -> prev = myList -> tail;
        myList -> tail = temp;
    }
}


void print(struct list l){
    struct node *temp;
    temp = l.head;
    while (temp!=NULL){
        printf("number in node is: %d\n", temp->val);
        temp = temp->next;
    }
}


void swap(struct node *a, struct node *b)
{
    int temp = a->val;
    a->val = b->val;
    b->val = temp;
}


void sort_ascending(struct list *myList){
    int swapped, i;
    struct node *temp1;
    struct node *ltemp = NULL;
    
    temp1 = myList->head;
    
    if (temp1 == NULL)
        return;
    
    do
    {
        swapped = 0;
        temp1 = myList->head;

        while (temp1->next != ltemp)
        {
            if (temp1->val > temp1->next->val)
            {
                swap(temp1, temp1->next);
                swapped = 1;
            }
            temp1 = temp1->next;
        }
        ltemp = temp1;
    }
    while (swapped);
}


void sort_descending(struct list *myList){
    int swapped, i;
    struct node *temp1;
    struct node *ltemp = NULL;
    
    temp1 = myList->head;
    
    if (temp1 == NULL)
        return;
    
    do
    {
        swapped = 0;
        temp1 = myList->head;
        
        while (temp1->next != ltemp)
        {
            if (temp1->val < temp1->next->val)
            {
                swap(temp1, temp1->next);
                swapped = 1;
            }
            temp1 = temp1->next;
        }
        ltemp = temp1;
    }
    while (swapped);
}


void remove_val(struct list *myList, int myval){
    if (myList->head == NULL)
    {
        printf("Node can't be deleted from an empty list.");
    }
    else
    {
        struct node *curr = myList->head;
        struct node *trail = NULL;
        
        while (curr != NULL)
        {
            if (curr->val == myval)
            {
                break;
            }
            else
            {
                trail = curr;
                curr = curr->next;
            }
        }
        
        if (curr == NULL)
        {
            printf("val couldn't be found in the list");
        }
        else
        {
            if (myList->head == curr)
            {
                myList->head = myList->head->next;
            }
            else
            {
                trail->next = curr->next;
            }
        }
        
        free(curr);
    }
}


void insert(struct list *myList, int loc, int myval){
    struct node *newNode;
    newNode = (struct node *) malloc(sizeof(struct node));
    
    if (myList->head == NULL){
        myList->head = newNode;
    }
    else
    {
        struct node *curr = myList->head;
        struct node *trail = NULL;
        
        while (curr != NULL)
        {
            if(curr->val == loc)
            {
                break;
            }
            else
            {
                trail = curr;
                curr = curr->next;
            }
        }
        
        if (curr == myList->head)
        {
            newNode->next = myList->head;
            myList->head = newNode;
            newNode->val = myval;
        }
        else
        {
            newNode->next = curr;
            trail->next = newNode;
            newNode->val = myval;
        }
    }
}


void clear(struct list *myList){
    struct node *temp;
    temp = myList->head;
    while (temp!=NULL) {
        myList->head = temp->next;
        free(temp);
        temp = myList->head;
    }
}
