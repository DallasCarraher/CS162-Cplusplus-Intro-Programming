//
//  test_list.h
//  
//
//  Created by Dallas Carraher on 6/5/16.
//  header file for function prototypes and struct types list and node
//

#include <stdio.h>
#include <stdlib.h>


struct node {
    int val;
    struct node *next;
    struct node *prev;
};

struct list {
    struct node *head;
    struct node *tail;
};


int length(struct list); //return number of nodes in the list

void print(struct list); // print the values in the list
void push_front(struct list *, int); //push to front of list
void push_back(struct list *, int); //push to end of list

void clear(struct list *); //remove all nodes from the list
void remove_val(struct list *, int); //remove nodes w/ int as val

void swap(struct node *a, struct node *b);
void sort_ascending(struct list *);
void sort_descending(struct list *);


void insert(struct list *, int, int); //insert into a location in the list, start at 0 for front