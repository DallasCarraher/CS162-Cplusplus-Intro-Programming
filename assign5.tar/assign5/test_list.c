//
//  test_list.c
//  Created by Dallas Carraher on 6/5/16.
//  6/5/2016
//  linked list of nodes
//  input is node vals
//  output is sorted linked list of nodes

#include "list.h"


int main(){
    
    char filename[20];
    struct list l;
    FILE *fileptr;
    char num[3]; //we will read positive integers 0-99
    
    printf("Enter filename: ");
    scanf("%s", filename);
    fileptr = fopen (filename,"r");
    
    
    //continue reading until eof
    while (fscanf(fileptr, "%s", num) !=EOF)
    {
        printf("number is: %d \n", atoi(num));
        //push_front(&l, atoi(num)); //push to front of list
        push_back(&l, atoi(num));//push to back of list
    }
    
    length(l);//print length of list
    print(l);//print the contents of the list
    
    sort_ascending(&l);//sort in ascending order
    print(l);//print the contents of the list
    
    sort_descending(&l);//sort in descending order
    print(l);//print the contents of the list
    
    
    int loc, myval; //initializing new integers for functions
    printf("Enter the node val where you want your new node to be in front of: ");//prompt user for item/int to add and location in list
    scanf("%d", &loc);
    printf("Enter the integer val you want your newnode to hold");
    scanf("%d", &myval);
    insert(&l, loc, myval); //insert new node in specific slot with a new integer val
    print(l);//print the contents of the list
    
    int guy;
    printf("Enter the node val you wish to remove from the list: ");
    scanf("%d", &guy);
    remove_val(&l, guy);//remove specific node with specific value/integer from list
    print(l);//print the contents of the list
    
    
    
    clear(&l);//clear list - no memory leaks
    

    fclose (fileptr);
    
    return 0;
}
