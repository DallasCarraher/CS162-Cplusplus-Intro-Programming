//
//  lab9.c
//  
//
//  Created by Dallas Carraher on 5/27/16.
//
//

#include <stdio.h>
#include <stdlib.h>


struct node {
    int val; //integer value within the node
    struct node *next; //a pointer to the next node in the list
};

struct stack {
    struct node *head; //pointer to the head of the stack / first node
    struct node *tail; //pointer to the tail of the stack / last node
};

void init(struct stack *myStack);
void push(struct stack *myStack, int item);
void pop(struct stack *myStack);
void display(struct stack *myStack);

int main(){

    int choice;
    int option = 1;
    
    void init();
    
    printf ("STACK OPERATION\n");
    
    while (option)
    {
        printf ("------------------------------------------\n");
        printf (" 1 --> PUSH \n");
        printf (" 2 --> POP \n");
        printf (" 3 --> DISPLAY \n");
        printf (" 4 --> EXIT \n");
        printf ("------------------------------------------\n");
        
        printf ("Enter your choice\n");
        scanf ("%d", &choice);
        
        switch (choice)
        {
            case 1: void push(myStack);
                break;
            case 2: void pop(myStack);
                break;
            case 3: void display(myStack);
                break;
            case 4: return 1;
        }
        
        fflush (stdin);
        printf ("Do you want to continue(Type 0 or 1)?\n");
        scanf ("%d", &option);
    }
    
    return 0;
}



void init(struct stack *myStack){
    int *newContent;
    newContent = malloc(sizeof(struct stack));
}

void push(struct stack *myStack, int item){

}

void pop(struct stack *myStack){
    
}

void display(struct stack *myStack){
    
}