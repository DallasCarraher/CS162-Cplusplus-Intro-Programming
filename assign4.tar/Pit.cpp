//
//  Bat.cpp
//  
//
//  Created by Dallas Carraher on 5/24/16.
//
//

#include "Header.h"

void Pit::percept(){
    cout << "You feel a draft" << endl;
}

int Pit::action(){
    return 2;
}