//
//  Player.cpp
//  
//
//  Created by Dallas Carraher on 5/24/16.
//
//

#include "Header.h"

void Player::drop(int cols, int rows, board new_board){
   
    int v2, v3;
 
    while(true){
    v2 = rand() % cols;
    v3 = rand() % rows;
    
        if(!new_board.is_event(rows, cols)){
            break;
        }
        
    }
    row_location = v3;
    col_location = v2;
    
}


void Player::movement(string move_type, int max_row, int max_col){
    
    cin >> move_type;
    
    if (move_type == "up"){
        if (row_location == 0){
            cout << "You have come to a wall" << endl;
            return;
        }
        row_location--;
        cout << "You walk North..." << endl;
    }
    else if(move_type == "down"){
        if (row_location == max_row + 1){
            cout << "You have come to a wall" << endl;
            return;
        }
        row_location++;
        cout << "You walk South..." << endl;
    }
    else if(move_type == "left"){
        if (col_location == 0){
            cout << "You have come to a wall" << endl;
            return;
        }
        col_location--;
        cout << "You walk West..." << endl;
    }
    else if(move_type == "right"){
        if (col_location == max_col + 1){
            cout << "You have come to a wall" << endl;
            return;
        }
        col_location++;
        cout << "You walk East" << endl;
    }
    
    else{
        cout << "Invalid input exiting..." << endl;
        exit(0);
    }
// sdafsadfjldfasjklfas jkl adfsjkla dfsjklas dfljasdf kjlasdf adflsadfs jk adfsdfjs adfjs jl afdsl;
    cout << "Row: " << row_location << " Col: " << col_location << endl;
}




