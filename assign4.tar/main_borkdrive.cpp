//
//  main.cpp
//  
//
//  Created by Dallas Carraher on 5/22/16.
//
//

#include "Header.h"


int main(int argc, char**argv){
    
    int rows = atoi(argv[1])-1;
    int cols = atoi(argv[2])-1;

    if(rows < 3 || cols < 3){
        cout << "Invalid input for cave dimensions. Exiting..." << endl;
        return 1;
    }
    
    srand(time(NULL));
    string move_type, direction;
    int choice;
    int restart = 1;
    int decision = 1;
    
    
    
    //restart game
    while (restart == 1){
    
      
    board new_board(rows, cols); //create a new cave
    Player jc; //player creation "JEREMY COLE"

    jc.drop(cols, rows, new_board); //drop jeremy into the cave
             cout << "You have been dropped into the Wumpus' Cave." << endl << endl;
  
    while(decision == 1){
        
        if (jc.get_arrows() == 0){
            cout << "You have no arrows. You have lost." << endl;
            cout << "do you wish to restart/continue to play? (1 = yes, 0 = no): ";
            cin >> restart;
        }
        
    //choice to move or shoot
    cout << "Would you like to move(0) or shoot(1)? (0 or 1): ";
    cin >> choice;
    
    if(choice == 1){
        cout << "Where do you want to shoot in the cave? (north, south, east or west?): "; cin >> direction;
        new_board.arrow(direction, jc.get_col(), jc.get_row(), rows-1, cols-1);
    }
    else if (choice == 0){
        cout << "Where would you like to move in the cave? (up, down, left, right): ";
        jc.movement(move_type, rows-1, cols-1);
        
        if (new_board.is_event(jc.get_row(), jc.get_col()+1)){
            new_board.percept(jc.get_row(), jc.get_col()+1);
        }
        else if (new_board.is_event(jc.get_row(), jc.get_col()-1)){
            new_board.percept(jc.get_row(), jc.get_col()-1);
        }
        else if (new_board.is_event(jc.get_row()+1, jc.get_col())){
            new_board.percept(jc.get_row()+1, jc.get_col());
        }
        else if (new_board.is_event(jc.get_row()-1, jc.get_col())){
            new_board.percept(jc.get_row()-1, jc.get_col());
        }
    }

    
        if (new_board.is_event(jc.get_row(), jc.get_col())){
            if (new_board.action(jc.get_row(), jc.get_col()) == 1){
                cout << "A Giant Bat picked you up and dropped you in another cave location!" << endl;
                int chef, jerry;
                chef = rand() % cols;
                jerry = rand() % rows;
                jc.get_col() == chef;
                jc.get_row() == jerry;
            }
            else if (new_board.action(jc.get_row(), jc.get_col()) == 2){
                cout << "You have fallen into a pitfall and died..." << endl;
                jc.get_dead() == true;
            }
            else if (new_board.action(jc.get_row(), jc.get_col()) == 3){
                cout << "You have run into the Wumpus! He eats you..." << endl;
                jc.get_dead() == true;
            }
            else if (new_board.action(jc.get_row(), jc.get_col()) == 4){
                cout << "You have found the Wumpus' Gold!" << endl;
                jc.get_gold() == true;
            }
        }
        
        
    
        if(jc.get_dead() == true){
            decision == 0;
        }

            
        if(jc.get_gold() == true && jc.get_kill() == true){
            cout << "You have won the game! Good Work Jeremy!" << endl;
            return 1;
        }
        
    }
        
    cout << "do you wish to restart/continue to play? (1 = yes, 0 = no): ";
    cin >> restart;
        
        
    }
    
    return 0;
}