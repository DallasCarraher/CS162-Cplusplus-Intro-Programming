//
//  Room->cpp
//  
//
//  Created by Dallas Carraher on 5/24/16->
//
//

#include "Header.h"


Room::Room(int & wumpus_borks, int & pit_borks, int & gold_borks, int & bat_borks){

    int v1 = rand() % 100;
    if (v1 < 5){
        if(wumpus_borks == 0){
        room_event = new Wumpus;
            wumpus_borks++;
    }
        else{
            //cout << "a wumpus has already been created" << endl;
        }
    }
    else if (v1 >= 5 && v1 <20){
        if(bat_borks < 2){
            room_event = new Bat;
            bat_borks++;
            //cout << "bat event created" << endl << bat_borks;
        }
        else{
            //cout << "bat already created" << endl;
        }
    }
    else if (v1 >= 20 && v1 <40){
        if(pit_borks < 2){
            room_event = new Pit;
            pit_borks++;
            //cout << "pit event created" << endl << pit_borks;
        }
        else{
            //cout << "pit already created" << endl;
        }
    }
    else if (v1 >= 40 && v1 <60){
        if(gold_borks == 0){
            room_event = new Gold;
            gold_borks++;
            //cout << "gold event created" << endl << gold_borks;
        }
        else{
            //cout << "gold already created" << endl;
        }
    }
 
    
}

bool Room::is_event(){
    if(room_event == NULL){
        return false;
    }
    return true;
}

void Room::percept(){
    room_event->percept();
}

int Room::action(){
    room_event->action();
    
}