//
//  Player.cpp
//  
//
//  Created by Dallas Carraher on 5/24/16.
//
//

#include "Header.h"

board::board(int rows, int cols){
    
    
    int wumpus_borks = 0;
    int bat_borks = 0;
    int gold_borks = 0;
    int pit_borks = 0;
    
    
   
    bork.resize(rows+1);
    for (int i = 0; i < bork.size(); i++){
        bork[i].resize(cols+1);
    }
    
    
    for (int j = 0; j < bork.size(); ++j){
        for(int k = 0; k < bork[k].size(); ++k){
            bork[j][k] = new Room(wumpus_borks, bat_borks, gold_borks, pit_borks);
        }
    }
    
    cout << "row size: " << bork.size() << " col size: " << bork[1].size() << endl;
}

bool board::is_event(int row, int col){
    
    if ((col == bork.size()) || (col == -1) ||  (row == -1) || (row == bork[1].size())){
        return false;
    }
    if ((col == bork[1].size()) || (col == +1) ||  (row == +1) || (row == bork.size())){
        return false;
    }
    
    if(bork[row][col]->is_event()){
        return true;
    }
    return false;
}

void board::percept(int row, int col){
    bork[row][col]->percept();
}

int board::action(int row, int col){
    bork[row][col]->action();
}

void board::arrow(string direction, int col_location, int row_location, int max_col, int max_row){
    
    if (direction == "north"){
        for(int i = 0; i < 3; i++){
            if(row_location == 0){
                cout << "You have hit a wall";
                return;
            }
            else{
                row_location--;
                if(bork[row_location][col_location]->is_event()){
                    int action = bork[row_location][col_location]->action();
                    if (action == 3){
                        cout << "You have killed the Wumpus! :) " << endl;
                    }
                    else{
                        cout << "You seem to have missed the Wumpus! :( " << endl;
                    }
                }
            }
        }
    }
    
    else if(direction == "south"){
        for(int j = 0; j < 3; j++){
            if(row_location == max_row){
                cout << "You have hit a wall";
                return;
            }
            else{
                row_location++;
                if(bork[row_location][col_location]->is_event()){
                    int action = bork[row_location][col_location]->action();
                    if (action == 3){
                        cout << "You have killed the Wumpus! :) " << endl;
                    }
                    else{
                        cout << "You seem to have missed the Wumpus! :( " << endl;
                    }
                }
            }
        }
    }
    
    else if(direction == "west"){
        for(int k = 0; k < 3; k++){
            if(col_location == 0){
                cout << "You have hit a wall";
                return;
            }
            else{
                col_location--;
                if(bork[row_location][col_location]->is_event()){
                    int action = bork[row_location][col_location]->action();
                    if (action == 3){
                        cout << "You have killed the Wumpus! :) " << endl;
                    }
                    else{
                        cout << "You seem to have missed the Wumpus! :( " << endl;
                    }
                }
            }
        }
    }
    
    else if(direction == "east"){
        for(int l = 0; l < 3; l++){
            if(col_location == max_col){
                cout << "You have hit a wall";
                return;
            }
            else{
                col_location++;
                if(bork[row_location][col_location]->is_event()){
                    int action = bork[row_location][col_location]->action();
                    if (action == 3){
                        cout << "You have killed the Wumpus! :) " << endl;
                    }
                    else{
                        cout << "You seem to have missed the Wumpus! :( " << endl;
                    }
                }
            }
        }
    }
    
    
    else{
        cout << "Invalid input exiting...";
        exit(0);
    }
    
    
    
}