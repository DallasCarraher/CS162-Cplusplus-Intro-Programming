//
//  Bat.cpp
//  
//
//  Created by Dallas Carraher on 5/24/16.
//
//

#include "Header.h"


void Gold::percept(){
    cout << "you see something shiny..." << endl;
}

int Gold::action(){
    return 4;
}