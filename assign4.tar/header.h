//
//  Header.h
//  
//
//  Created by Dallas Carraher on 5/20/16.
//
//

#ifndef Header_h
#define Header_h
#include <iostream>
#include <cmath>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <time.h>
#include <string>


using namespace std;

//Event class
class Event{
protected:
    
public:
    virtual void percept() = 0;
    virtual int action() = 0;
};
//Event class\


//Room Class
class Room{
protected:
    Event * room_event = NULL;
    bool exit;
public:
    Room(int&, int&, int&, int&);
    ~Room();
    bool is_event();
    int action();
    void percept();
};
//Room class\


//board class
class board{
protected:
    vector<vector<Room*> > bork;
    
public:
    board(){};
    board(int, int);
    
    bool is_event(int, int);
    vector<vector<Room*> > get_board(){return bork;};
    void arrow(string, int, int, int, int);
    void percept(int, int);
    int action(int, int);
    
};

//player class
class Player{
protected:
    int arrows;
    int row_location;
    int col_location;
    bool has_gold;
    bool kilt_wumpus;
    bool dead;
public:
    Player(){
        arrows = 3;
        row_location = 0;
        col_location = 0;
        has_gold = false;
        kilt_wumpus = false;
        dead = false;
    }
    void drop(int, int, board);
    void movement(string, int, int);
    
    int get_col(){return col_location;};
    int get_row(){return row_location;};
    int get_arrows(){return arrows;};
    int get_gold(){return has_gold;};
    int get_kill(){return kilt_wumpus;};
    int get_dead(){return dead;};
};
//player class\

class Wumpus: public Event{
protected:

public:
    void percept();
    int action();
};

class Bat: public Event{
protected:

public:
    void percept();
    int action();
};


class Pit: public Event{
protected:

public:
    void percept();
    int action();
};


class Gold: public Event{
protected:
    
public:
    void percept();
    int action();
};







#endif /* Header_h */
