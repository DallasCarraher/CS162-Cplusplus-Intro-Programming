//
//  Bat.cpp
//  
//
//  Created by Dallas Carraher on 5/24/16.
//
//

#include "Header.h"


void Bat::percept(){
    cout << "you hear something..." << endl;
}

int Bat::action(){
    return 1;
}



/*
int ve, vr;

while(true){
    ve = rand() % cols;
    vr = rand() % rows;
    if(!new_board.is_event(rows-1, cols-1)){
        break;
    }
}
row_location = ve;
col_location = vr;
*/