//
//  Bat.cpp
//  
//
//  Created by Dallas Carraher on 5/24/16.
//
//

#include "Header.h"


void Wumpus::percept(){
    cout << "You smell something awful" << endl;
}

int Wumpus::action(){
    return 3;
}