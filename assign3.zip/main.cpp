#include "header.h"
#include <iostream>

int main(){
    
    
    srand(time(NULL));
    int purchase, purchase2, profit;
    char choice;

	zoo myzoo;
    
    
	cout << "welcome to your zoo! We've given you $100,000 to start purchasing animals." << endl;
    
	cout << "Would you like to buy 0, 1, or 2 Tigers?: " << endl;
    cin >> purchase;
    myzoo.set_tigers(purchase);
	cout << "Would you like to buy 0, 1, or 2 Penguins?: " << endl;
    cin >> purchase;
    myzoo.set_penguins(purchase);
	cout << "Would you like to buy 0, 1, or 2 Polarbears?: " << endl;
    cin >> purchase;
    myzoo.set_polarbears(purchase);
    
    //day by day
    for (int day = 1; day < 10000; day++){
        
        char quit;
        
        myzoo.feeds_cost(); //substracts feeding cost from bank
        
        myzoo.add_age(); //adds +1 to age of all animals in exhibit arrays
        
        myzoo.random_gen(); //random event
        
        cout << "Bank Value: " << myzoo.get_bank() << endl;
        
        
        cout << "Would you like to buy any more animals? (t), (p), (b) or (n) for no: ";
        cin >> choice;
        
        cout << "How many? (0, 1, 2): ";
        if (choice = 't'){
            cin >> purchase2;
            myzoo.set_tigers(purchase2);
        }
        else if (choice = 'p'){
            cin >> purchase2;
            myzoo.set_penguins(purchase2);
        }
        else if (choice = 'b'){
            cin >> purchase2;
            myzoo.set_polarbears(purchase2);
        }
        else{ cout << "No purchases made."; }
        
        profit = ((myzoo.get_num_tigers() * 1000) + (myzoo.get_num_penguins() * 50) + (myzoo.get_num_polarbears() * 250));
        cout << "Payoff today was: ";
        cout << profit;
        myzoo.addprofit(profit);
        
        cout << "Bank Value: " << myzoo.get_bank() << endl;
        if (myzoo.get_bank() <= 0){
            cout << "Sorry but you've gone bankrupt! You lose!" << endl;
            return 1;
        }
        else if (myzoo.get_bank() <= 5000 && myzoo.get_bank() <= 0) {
            cout << "You're very close to bankruptcy!" << endl;
        }
        
        cout << endl << endl << "Enter any letter and press enter to move on to the next day... to stop, simply type (q) and press enter..." << endl;
        cin.ignore();
        cin >> quit;
        if (quit != 'q'){ cout << endl << endl << "the next day..." << endl << endl; }
        else{ break; }
    }
    //?day by day
    
        return 0;
}
