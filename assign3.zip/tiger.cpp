#include "header.h"

tiger::tiger(){
    age = 3;
    cost = 10000;
    feeding_cost = 100;
    bonus = 0;
    payoff = 1000;
    
}


int tiger::get_age(){
    return age;
}

tiger::tiger(int input){
    age = input;
}

void tiger::set_age(int input){
    age = input;
}

int tiger::pay(){
    cout << "tiger payoff: " << payoff;
}