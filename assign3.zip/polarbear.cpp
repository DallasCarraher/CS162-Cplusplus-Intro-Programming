#include "header.h"

polarbear::polarbear(){
    age = 3;
    cost = 5000;
    feeding_cost = 60;
    payoff = 250;
}

polarbear::polarbear(int input){
    age = input;
}

int polarbear::get_age(){
    return age;
}

void polarbear::set_age(int input){
    age = input;
}

int polarbear::pay(){
    cout << "Polarbear payoff: " << payoff;
}