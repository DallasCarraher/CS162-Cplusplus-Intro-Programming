#ifndef header_h
#define header_h

#include <iostream>
#include <string>
#include <iomanip>
#include <cstdlib>
#include <string.h>
#include <cmath>
#include <vector>

using namespace std;

class animal{
	protected:
		string name;
		int age;
		int cost;
		int feeding_cost;
		int num_babies;
		int payoff;

	public:
};



class tiger : public animal{
	private:
		int bonus;
    
	public:
        tiger();
        tiger(int input);
        int get_age();
        void set_age(int input);
        int get_bonus();
        int pay();
};



class penguin : public animal{
	private:
	public:
		penguin();
        penguin(int input);
        int get_age();
        void set_age(int input);
        int pay();
};



class polarbear : public animal{
	private:
	public:
		polarbear();
        polarbear(int input);
        int get_age();
        void set_age(int input);
        int pay();
};



class zoo{
protected:
    int bank;
    int num_tigers;
    int num_penguins;
    int num_polarbears;
    vector<tiger*> tiger_exhibit;
    vector<penguin*> penguin_exhibit;
    vector<polarbear*> polar_exhibit;
    
    
public:
    zoo(); //default constructor
    ~zoo(); //destructor lel
   
    //mutators
    void set_bank(int input);
    void set_tigers(int input);
    void set_penguins(int input);
    void set_polarbears(int input);
    
    //accessors
    int get_bank();
    
    int get_num_tigers();
    
    int get_num_penguins();
    
    int get_num_polarbears();
    
    //others
    bool bankrupt();
    
    void random_gen();
    
    void feeds_cost();
    
    void add_age();
    
    int addprofit(int input);
    
};








#endif



