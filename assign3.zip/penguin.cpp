#include "header.h"

penguin::penguin(){
    age = 3;
    cost = 1000;
    feeding_cost = 20;
    payoff = 50;
}

penguin::penguin(int input){
    age = input;
}

int penguin::get_age(){
    return age;
}

void penguin::set_age(int input){
    age = input;
}

int penguin::pay(){
    cout << "Penguin payoff: " << payoff;
}