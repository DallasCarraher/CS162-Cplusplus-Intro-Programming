#include "header.h"

zoo::zoo(){
    bank = 100000;
}

zoo::~zoo(){
    cout << tiger_exhibit[0]->get_age();
    
    cout << "clearing vector arrays and swapping...";
    //tiger_exhibit.clear();
    vector<tiger*>().swap(tiger_exhibit);

    //penguin_exhibit.clear();
    vector<penguin*>().swap(penguin_exhibit);

    //polar_exhibit.clear();
    vector<polarbear*>().swap(polar_exhibit);
}

/*
void zoo::set_bank(int input){
    bank = input;
}
*/
 
void zoo::set_tigers(int input){
    if (input == 0){
		cout << "You have decided not to buy any tigers to start." << endl;
	}
	else if (input == 1){
		cout << "You have decided to purchase 1 tiger. $10,000 has been deducted from your bank." << endl;
        bank -= 10000;
        tiger* tiger1 = new tiger[1];
        tiger_exhibit.push_back(tiger1);
        delete[] tiger1;
	}
	else if (input == 2){
		cout << "You have decided to purchase 2 tigers. $20,000 has been deducted from your bank." << endl;
        bank -= 20000;
        for (int i=0; i<2; i++){
            tiger* tiger1 = new tiger[1];
            tiger_exhibit.push_back(tiger1);
            delete[] tiger1;
        }
	}
	else{
		cout << "Invalid purchase attempt. Exiting..." << endl;
        exit(0);
	}
}

void zoo::set_penguins(int input){
    if (input == 0){
        cout << "You have decided not to buy any penguins to start." << endl;
    }
    else if (input == 1){
        cout << "You have decided to purchase 1 penguin. $1,000 has been deducted from your bank." << endl;
        bank -= 1000;
        penguin* penguin1 = new penguin[1];
        penguin_exhibit.push_back(penguin1);
        delete[] penguin1;
    }
    else if (input == 2){
        cout << "You have decided to purchase 2 penguins. $2,000 has been deducted from your bank." << endl;
        bank -= 2000;
        for (int i=0; i<2; i++){
            penguin* penguin1 = new penguin[1];
            penguin_exhibit.push_back(penguin1);
            delete[] penguin1;
        }
    }
    else{
        cout << "Invalid purchase attempt. Exiting..." << endl;
        exit(0);
    }
}

void zoo::set_polarbears(int input){
    if (input == 0){
        cout << "You have decided not to buy any polarbears to start." << endl;
    }
    else if (input == 1){
        cout << "You have decided to purchase 1 polarbear. $5,000 has been deducted from your bank." << endl;
        bank -= 5000;
        polarbear* polarbear1 = new polarbear[1];
        polar_exhibit.push_back(polarbear1);
        delete[] polarbear1;
    }
    else if (input == 2){
        cout << "You have decided to purchase 2 polarbears. $10,000 has been deducted from your bank." << endl;
        bank -= 10000;
        for (int i=0; i<2; i++){
            polarbear* polarbear1 = new polarbear[1];
            polar_exhibit.push_back(polarbear1);
            delete[] polarbear1;
        }
    }
    else{
        cout << "Invalid purchase attempt. Exiting..." << endl;
    }
}


int zoo::get_bank(){
    return bank;
}

int zoo::get_num_tigers(){
	return tiger_exhibit.size();
}

int zoo::get_num_penguins(){
	return penguin_exhibit.size();
}

int zoo::get_num_polarbears(){
	return polar_exhibit.size();
}

void zoo::random_gen(){
    //random event generator
    int num = (rand() % 100); //for random events
    
    if (num <= 25){
        char deadanimal;
        cout << "Random event generated: a sickness has occurred!" << endl << "which animal do you want to kill? (t) tiger? (p) penguin? Or (b) polarbear?: ";
        cin >> deadanimal;
        if (deadanimal = 't'){
            tiger_exhibit.pop_back();
        }
        else if(deadanimal = 'p'){
            penguin_exhibit.pop_back();
        }
        else if(deadanimal = 'b'){
            polar_exhibit.pop_back();
        }
        else{ cout << "invalid response. Exiting... "; }
    }
    if (num >=26 and num <=50){
        int num2 = (rand() % 250) + 250;
        bank += num2;
        bank += 300; //polarbear payoff and penguin added
    }
    if (num >=51 and num <=75){
        char babyanimal;
        cout << "An animal baby was born today! Which animal will have a baby? (t) tiger? (p) penguin? Or (b) polarbear?: ";
        cin >> babyanimal;
        if (babyanimal = 't'){
            tiger* tiger1 = new tiger[1];
            tiger_exhibit.push_back(tiger1);
            delete[] tiger1;
            tiger_exhibit.back()->set_age(0);
        }
        else if (babyanimal = 'p'){
            penguin* penguin1 = new penguin[1];
            penguin_exhibit.push_back(penguin1);
            delete[] penguin1;
            penguin_exhibit.back()->set_age(0);
        }
        else if (babyanimal = 'b'){
            polarbear* polarbear1 = new polarbear[1];
            polar_exhibit.push_back(polarbear1);
            delete[] polarbear1;
            polar_exhibit.back()->set_age(0);
        }
    }
    if (num >=76 and num <=100){
        cout << "No Random Event generated! The zoo is unchanged today!" << endl;
    }
    //?random event generator
}

void zoo::feeds_cost(){
    //feeding cost
    bank -= tiger_exhibit.size() * 100;
    bank -= penguin_exhibit.size() * 20;
    bank -= polar_exhibit.size() * 60;
    //?feeding cost
}


void zoo::add_age(){
    //age
    for (int i = 0; i < tiger_exhibit.size(); i++){
        tiger_exhibit[i]->set_age(tiger_exhibit[i]->get_age()+1);
    }
    for (int i = 0; i < penguin_exhibit.size(); i++){
        penguin_exhibit[i]->set_age(penguin_exhibit[i]->get_age()+1);
    }
    for (int i = 0; i < polar_exhibit.size(); i++){
        polar_exhibit[i]->set_age(polar_exhibit[i]->get_age()+1);
    }
    //?age
}


int zoo::addprofit(int input){
    bank += input;
}