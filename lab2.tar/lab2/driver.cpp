#include "ltr_header"

//main function file driver.cpp
int main() {
	void count_letters();
	void output_letters();		
	return 0;
}
