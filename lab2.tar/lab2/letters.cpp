// Implementation file with functions
// letters.cpp

#include "ltr_header.h"



//this function takes a user input for filename, locates the file and reads the text.
void count_letters(ifstream &, int *){
	
	//declaration of string and char variables
	string filename, temp;
	char i;
	
	//taking a user input for filename
	cout << "What is the name of the file to read from?: ";
	cin >> temp;

	//declaration of fstream
	ifstream inFile;

	//conversion of temp string to filename
	filename = temp + ".txt";
	inFile.open(filename.c_str());
	
	//exit if input filename isn't successful
	if (inFile.fail()) {
		cout << "didn't open" << endl;
		return;
	}
	
	//initializes the array of structures (type lcount, variable stats)
	for (int j = 0; j < ALPHABET; j++) {
		stats[j].count = 0;
		stats[j].i = ('a' + j);
	}
	
	//while loop that 
	while(!inFile.eof()) {
		inFile.get(i);
		
		if (i >= 'a' && i <= 'z') {
			stats[i - 'a'].count++;
		}
		
		if (i >= 'A' && i <= 'Z') {
			stats[i - 'A'].count++;
		}
	}
	
	inFile.close();
	
	
}

//
void output_letters(ifstream &, int *){
	
	ofstream outFile;
	outFile.open("output.txt", std::ios::app);
	for(int h = 0; h < ALPHABET; h++){
		outFile << stats[h].i << ": " << stats[h].count << "  ";
	}
	
	
	
}
